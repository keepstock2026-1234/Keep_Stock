from core.crud_base import CrudBase
from core.database import conectar_supabase
from core.validator import Validator


class Produto(CrudBase):
    table = "camaras_frias"
    fields = [
        "id_produto",
        "nome_produto",
        "gavetas",
        "refrigeradores_disp",
        "temperatura_prod",
    ]

    def __init__(self,id_produto, nome_produto, gavetas, refrigeradores_disp, temperatura_prod):
        self.id_produto = id_produto
        self.nome_produto = nome_produto
        self.gavetas = gavetas
        self.refrigeradores_disp = refrigeradores_disp
        self.temperatura_prod = temperatura_prod

    def validate(self):
        erros = [
            Validator.required(self.nome_produto, "nome dos produtos"),
            Validator.required(self.gavetas, "gavetas"),
            Validator.non_negative(self.refrigeradores_disp, "refrigeradores"),
            Validator.required(self.temperatura_prod, "ptemperatura do produto"),
        ]
        return [erro for erro in erros if erro]  # ARRUMAR AS VALIDAÇÕES!

    @classmethod
    def warning_temperature(cls):
        conexao = Database.connect()
        cursor = conexao.cursor(dictionary=True)
        try:
            sql = "SELECT * FROM  WHERE temperatura_atual <= temperatura_minima ORDER BY nome"
            cursor.execute(sql)
            return cursor.fetchall()
        finally:
            cursor.close()
            conexao.close()

    @classmethod
    def update_temperatura(cls, id, nova_tempertura, connection=None):
        conexao = connection or Database.connect()
        cursor = conexao.cursor()
        try:
            sql = "UPDATE camara_fria SET temperatura_atual = %s WHERE id = %s"
            cursor.execute(sql, (nova_quantidade, id))
            if connection is None:
                conexao.commit()
            return cursor.rowcount
        except Exception:
            if connection is None:
                conexao.rollback()
            raise
        finally:
            cursor.close()
            if connection is None:
                conexao.close()

    @classmethod
    def has_related_records(cls, id): # USA, DEIXR ESTA FUNÇÃO CORRETA
        conexao = Database.connect()
        cursor = conexao.cursor()
        try:
            queries = [
                "SELECT COUNT(*) FROM alertas WHERE produto_id = %s",
            ]
            total = 0
            for sql in queries:
                cursor.execute(sql, (id,))
                total += cursor.fetchone()[0]
            return total > 0
        finally:
            cursor.close()
            conexao.close()

    @classmethod
    def safe_delete(cls, id):
        produto = cls.find_by_id(id)
        if not produto:
            raise ValueError("Cãmara fria não encontrada.")
        if cls.has_related_records(id):
            raise ValueError("Não é possível excluir a câmara fria porque ele possui outras tabelas vinculadas .")
        cls.delete(id)
