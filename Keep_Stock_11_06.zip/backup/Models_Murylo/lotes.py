from core.crud_base import CrudBase
from core.database import conectar_supabase
from core.validator import Validator


class Lotes(CrudBase):
    table = "lotes"
    fields = [
        "id_produto",
        "id_fornecedor",
        "data_fabricacao"
        "data_validade",
        "quantidade_lote",
        "quantidade_max",
        "quantidade_min"
    
    ]

    def __init__(self, id_produto,id_fornecedor,data_fabricacao,  data_validade, quantidade_lote,quantidade_max, quantidade_min):
        self.id_produto = id_produto
        self.id_fornecedor = id_fornecedor
        self.data_fabricacao = data_fabricacao
        self.data_validade = data_validade
        self.quantidade_lote = quantidade_lote
        self.quantidade_max = quantidade_max
        self.quantidade_min = quantidade_min

    def validate(self):
        erros = [
            Validator.required(self.data_fabricacao, "data fabricação"),
            Validator.required(self.data_validade, "data validade"),
            Validator.non_negative(self.quantidade_lote, "qquantidade_lote"),
            Validator.non_negative(self.quantidade_max, "quantidade maxima"),
            Validator.non_negative(self.quantidade_min, "quantidade minina"),
        ]
        return [erro for erro in erros if erro]  #ARRUMAR AS VALIDAÇÕES!

    @classmethod
    def low_stock(cls):
        conexao = Database.connect()
        cursor = conexao.cursor(dictionary=True)
        try:
            sql = "SELECT * FROM lotes WHERE quantidade <= quantidade_min ORDER BY numero_lote"
            cursor.execute(sql)
            return cursor.fetchall()
        finally:
            cursor.close()
            conexao.close()

    @classmethod
    def update_quantity(cls, id, nova_quantidade, connection=None):
        conexao = connection or Database.connect()
        cursor = conexao.cursor()
        try:
            sql = "UPDATE lote SET quantidade = %s WHERE id = %s"
            cursor.execute(sql, (nova_quantidade, id))
            if connection is None:
                conexao.commit()
            return cursor.rowcount
        except Exception:
            if connection is None:
                conexao.rollback()
            raise
        finally:
            cursor.close()
            if connection is None:
                conexao.close()

    @classmethod
    def has_related_records(cls, id): # LOTES TAMBÉM PASSAM POR MOTVIMENTAÇÕES, DEIXR ESTA FUNÇÃO CORRETA
        conexao = Database.connect()
        cursor = conexao.cursor()
        try:
            queries = [
                "SELECT COUNT(*) FROM areas_estoque WHERE produto_id = %s",
                "SELECT COUNT(*) FROM descartes WHERE produto_id = %s",
                "SELECT COUNT(*) FROM devolucao WHERE produto_id = %s",
                "SELECT COUNT(*) FROM entradas_produtos WHERE produto_id = %s",
                "SELECT COUNT(*) FROM inspecoes_estoque WHERE produto_id = %s",
                "SELECT COUNT(*) FROM movimentacoes_estoque WHERE produto_id = %s",
                "SELECT COUNT(*) FROM pedido_itens WHERE produto_id = %s",
                "SELECT COUNT(*) FROM saidas_produtos WHERE produto_id = %s"
            ]
            total = 0
            for sql in queries:
                cursor.execute(sql, (id,))
                total += cursor.fetchone()[0]
            return total > 0
        finally:
            cursor.close()
            conexao.close()

    @classmethod
    def safe_delete(cls, id):
        produto = cls.find_by_id(id)
        if not produto:
            raise ValueError("Lote não encontrado.")
        if cls.has_related_records(id):
            raise ValueError("Não é possível excluir o lote porque ele possui outras tabelas vinculadas.")
        cls.delete(id)
