from datetime import datetime
from core.crud_base import CrudBase
from core.database import conectar_supabase


class Movimentacoes_estoque(CrudBase):
    table = "movimentacoes_estoque"
    fields = [
        "id_lote",
        "id_usuario",
        "tipo_movimentacao", 
        "quantidade", 
        "data_hora"]

    def __init__(self, id_lote, id_usuario,tipo_movimentacao, quantidade, data_hora=None):
        self.id_lote = id_lote
        self.id_usuario = id_usuario
        self.tipo_movimentacao = tipo_movimentacao
        self.quantidade = quantidade
        self.data_hora = data_hora or datetime.now()

    @classmethod
    def find_all_with_product(cls):
        conexao = Database.connect()
        cursor = conexao.cursor(dictionary=True)
        try:
            sql = """
            SELECT m.id, l.id AS lote, m.tipo_movimentacao, m.quantidade, m.data_hora
            FROM movimentacao m
            INNER JOIN lote l ON m.lote_id = l.id
            ORDER BY m.data_movimentacao DESC
            """
            cursor.execute(sql)
            return cursor.fetchall()
        finally:
            cursor.close()
            conexao.close()
