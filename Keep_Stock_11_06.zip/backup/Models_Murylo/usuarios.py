from core.crud_base import CrudBase
from core.database import conectar_supabase
from core.validator import Validator
 
class Usuarios(CrudBase):
    table = "usuarios"
    fields = [
        "nome",
        "email",
        "senha",
        "cpf",
        "telefone",
        "ativo",
        "criado_em"
    ]
 
    def __init__(self, nome, email, senha, cpf,
                 telefone, ativo, criado_em):
        self.nome = nome
        self.email = email
        self.senha = senha
        self.cpf = cpf
        self.telefone = telefone
        self.ativo = ativo
        self.criado_em = criado_em
 
    def validate(self):
        erros = [
            Validator.validar_nome(self.nome, "nome"),
            Validator.validar_email(self.email, "email"),
            Validator.non_negative(self.senha, "senha"),
            Validator.validar_cpf(self.cpf, "cpf"),
            Validator.non_negative(self.telefone, "telefone")
            Validator.required(self.ativo, "ativo")
            Validator.required(self.criado_em, "criado_em")
        ]
        return [erro for erro in erros if erro]
 
 
    @classmethod
    def has_related_records(cls, id):
        conexao = Database.connect()
        cursor = conexao.cursor()
        try:
            queries = [
                "SELECT COUNT(*) FROM saidas_produtos WHERE usuario_id = %s", 
                "SELECT COUNT(*) FROM notificacoes WHERE usuario_id = %s",
                "SELECT COUNT(*) FROM movimentacoes_estoque WHERE usuario_id = %s"
                "SELECT COUNT(*) FROM inspecoes_estoque WHERE usuario_id = %s"
                "SELECT COUNT(*) FROM entradas_produtos WHERE usuario_id = %s"
                "SELECT COUNT(*) FROM funcionarios WHERE usuario_id = %s"
            ]
            total = 0
            for sql in queries:
                cursor.execute(sql, (id,))
                total += cursor.fetchone()[0]
            return total > 0
        finally:
            cursor.close()
            conexao.close()
 
    @classmethod
    def safe_delete(cls, id):
        usuario = cls.find_by_id(id)
        if not usuario:
            raise ValueError("usuario não encontrado.")
        if cls.has_related_records(id):
            raise ValueError("Não é possível excluir o usuario")
        cls.delete(id)