// Função para abrir modal de edição
function abrirModalEditar(id, nome, cpf_cnpj, telefone, email, codigo_postal) {
    // Preencher os campos do formulário
    document.getElementById('edit_nome').value = nome || '';
    document.getElementById('edit_cpf_cnpj').value = cpf_cnpj || '';
    document.getElementById('edit_telefone').value = telefone || '';
    document.getElementById('edit_email').value = email || '';
    document.getElementById('edit_codigo_postal').value = codigo_postal || '';
    
    // Atualizar a ação do formulário com o ID
    const form = document.getElementById('formEditar');
    if (form) {
        form.action = `/cliente/atualizar/${id}`;
    }
    
    // Armazenar o ID para ações de exclusão
    window.idAtualEditar = id;
    
    // Abrir o offcanvas
    const offcanvas = new bootstrap.Offcanvas(document.getElementById('offcanvasEditar'));
    offcanvas.show();
}

// Função para abrir modal de edição de fornecedor
function abrirModalEditarFornecedor(id, nome, cnpj, telefone, email, cep) {
    // Preencher os campos do formulário
    document.getElementById('edit_nome').value = nome || '';
    document.getElementById('edit_cnpj').value = cnpj || '';
    document.getElementById('edit_telefone').value = telefone || '';
    document.getElementById('edit_email').value = email || '';
    document.getElementById('edit_cep').value = cep || '';
    
    // Atualizar a ação do formulário com o ID
    const form = document.getElementById('formEditar');
    if (form) {
        form.action = `/fornecedor/atualizar/${id}`;
    }
    
    // Armazenar o ID para ações de exclusão
    window.idAtualEditar = id;
    
    // Abrir o offcanvas
    const offcanvas = new bootstrap.Offcanvas(document.getElementById('offcanvasEditar'));
    offcanvas.show();
}

// Função para excluir cliente
function excluirCliente() {
    if (window.idAtualEditar && confirm('Tem certeza que deseja excluir este cliente?')) {
        window.location.href = `/cliente/excluir/${window.idAtualEditar}`;
    }
}

// Função para excluir fornecedor
function excluirFornecedor() {
    if (window.idAtualEditar && confirm('Tem certeza que deseja excluir este fornecedor?')) {
        window.location.href = `/fornecedor/excluir/${window.idAtualEditar}`;
    }
}

// Event listeners para botões de exclusão
document.addEventListener('DOMContentLoaded', function() {
    const btnExcluirCliente = document.getElementById('btnExcluirCliente');
    const btnExcluirFornecedor = document.getElementById('btnExcluirFornecedor');
    
    if (btnExcluirCliente) {
        btnExcluirCliente.addEventListener('click', excluirCliente);
    }
    
    if (btnExcluirFornecedor) {
        btnExcluirFornecedor.addEventListener('click', excluirFornecedor);
    }
});
