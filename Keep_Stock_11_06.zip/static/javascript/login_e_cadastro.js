let isAppActive = false;

function switchAuthView(viewId) {
    document.querySelectorAll('.view-section').forEach((el) => {
        el.classList.remove('active');
    });

    const targetView = document.getElementById(viewId);
    if (targetView) {
        targetView.classList.add('active');
    }
}

function doLogin() {
    document.querySelectorAll('.view-section').forEach((el) => {
        el.classList.remove('active');
    });

    isAppActive = true;
}

async function cadastrarUsuario(e) {
    e.preventDefault();

    const dados = {
        nome: e.target.nome_completo.value.trim(),
        email: e.target.email.value.trim(),
        cpf: e.target.cpf.value.replace(/\D/g, ''),
        senha: e.target.senha.value,
        confirmar_senha: e.target.confirmar_senha.value
    };

    if (dados.senha !== dados.confirmar_senha) {
        alert("As senhas não coincidem.");
        return;
    }

    console.log("Dados capturados para envio:", dados);

    try {
        const response = await fetch('http://127.0.0.1:5000/cadastrar', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(dados)
        });

        const resultado = await response.json();

        if (response.ok) {
            alert("Sucesso: " + resultado.mensagem);
            e.target.reset();
            switchAuthView('view-login');
        } else {
            alert("Erro no cadastro: " + (resultado.erro || "Erro desconhecido"));
        }
    } catch (err) {
        alert("Erro de conexão com o servidor Python.");
    }
}

async function realizarLogin(e) {
    e.preventDefault();

    const dados = {
        email: e.target.email.value.trim(),
        senha: e.target.senha.value
    };

    try {
        const response = await fetch('http://127.0.0.1:5000/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(dados)
        });

        const resultado = await response.json();

        if (response.ok) {
            alert("Bem-vindo, " + resultado.nome + "!");
            doLogin();
            window.location.href = 'base.html';
        } else {
            alert("Erro no login: " + (resultado.erro || "Erro desconhecido"));
        }
    } catch (err) {
        alert("Erro de conexão com o servidor.");
    }
}

document.addEventListener('DOMContentLoaded', () => {
    const formLogin = document.getElementById('form_login');
    const formCadastro = document.getElementById('form_cadastro');
    const linkCadastro = document.getElementById('link-cadastro');
    const linkLogin = document.getElementById('link-login');

    if (formLogin) {
        formLogin.addEventListener('submit', realizarLogin);
    }

    if (formCadastro) {
        formCadastro.addEventListener('submit', cadastrarUsuario);
    }

    if (linkCadastro) {
        linkCadastro.addEventListener('click', (e) => {
            e.preventDefault();
            switchAuthView('view-cadastro');
        });
    }

    if (linkLogin) {
        linkLogin.addEventListener('click', (e) => {
            e.preventDefault();
            switchAuthView('view-login');
        });
    }
});