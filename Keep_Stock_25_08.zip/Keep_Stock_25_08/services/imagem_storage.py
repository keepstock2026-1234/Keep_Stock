import os
import uuid

from supabase import create_client


SUPABASE_URL = "https://gysiqyxpmlxmlolqzaqs.supabase.co"
SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imd5c2lxeXhwbWx4bWxvbHF6YXFzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzQ5NjA3MDYsImV4cCI6MjA5MDUzNjcwNn0.Rst-gDutHxMCXUxGP2HYgRSnsUhip7tAevtsE9sWh4A"

supabase = create_client(SUPABASE_URL,SUPABASE_KEY)

BUCKET = "Imagens - Produtos"

EXTENSOES_PERMITIDAS = {
    ".jpeg",
    ".png",
    ".webp"
}


def upload_imagem(arquivo):

    if not arquivo or not arquivo.filename:
        return None

    extensao = os.path.splitext(
        arquivo.filename
    )[1].lower()

    if extensao not in EXTENSOES_PERMITIDAS:
        raise ValueError(
            "Formato de imagem não permitido. "
            "Use JPEG, PNG ou WEBP."
        )

    nome_arquivo = (
        f"{uuid.uuid4()}{extensao}"
    )

    caminho = f"Imagens - Produtos/{nome_arquivo}"

    arquivo_bytes = arquivo.read()

    supabase.storage \
        .from_(BUCKET) \
        .upload(
            caminho,
            arquivo_bytes,
            {
                "content-type": arquivo.content_type
            }
        )

    return caminho


def obter_url_imagem(caminho):

    if not caminho:
        return None

    return supabase.storage \
        .from_(BUCKET) \
        .get_public_url(caminho)


def deletar_imagem(caminho):

    if not caminho:
        return

    supabase.storage \
        .from_(BUCKET) \
        .remove([caminho])