import requests
import urllib.parse
from flask import Flask, request, jsonify
from flask_cors import CORS
from supabase import create_client, Client

app = Flask(__name__)
CORS(app) 

# --- CONFIGURAÇÕES ---
SUPABASE_URL = "https://gysiqyxpmlxmlolqzaqs.supabase.co"
SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imd5c2lxeXhwbWx4bWxvbHF6YXFzIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzQ5NjA3MDYsImV4cCI6MjA5MDUzNjcwNn0.Rst-gDutHxMCXUxGP2HYgRSnsUhip7tAevtsE9sWh4A" 

# Inicializa o cliente Supabase no Python
def conectar_supabase():
    supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)

if __name__ == '__main__':
    app.run(debug=True, port=5000)
