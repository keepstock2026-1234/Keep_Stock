from core.crud_base import CrudBase
from core.database import conectar_supabase
from core.validator import Validator

class Produto(CrudBase):
    table = "camaras_frias"
    fields = [
        "nome",
        "temperatura_atual",
        "temperatura_min",
        "temperatura_max",
        "id_camara_fria",
    ]

    def __init__(self, nome, temperatura_min, temperatura_max, id_camara_fria):
        self.nome = nome
        self.temperatura_max = temperatura_max
        self.temperatura_min = temperatura_min
        self.id_camara_fria = id_camara_fria

    def validate(self):
        erros = [
            Validator.required(self.nome, "nome"),
            Validator.non_negative(self.quantidade, "quantidade"),
            Validator.non_negative(self.estoque_minimo, "estoque mínimo"),
            Validator.non_negative(self.preco_custo, "preço de custo"),
            Validator.non_negative(self.preco_venda, "preço de venda")
        ]
        return [erro for erro in erros if erro]  # ARRUMAR AS VALIDAÇÕES!

    @classmethod
    def warning_temperature(cls):
        conexao = Database.connect()
        cursor = conexao.cursor(dictionary=True)
        try:
            sql = "SELECT * FROM  WHERE temperatura_atual <= temperatura_minima ORDER BY nome"
            cursor.execute(sql)
            return cursor.fetchall()
        finally:
            cursor.close()
            conexao.close()

    @classmethod
    def update_temperatura(cls, id, nova_tempertura, connection=None):
        conexao = connection or Database.connect()
        cursor = conexao.cursor()
        try:
            sql = "UPDATE camara_fria SET temperatura_atual = %s WHERE id = %s"
            cursor.execute(sql, (nova_quantidade, id))
            if connection is None:
                conexao.commit()
            return cursor.rowcount
        except Exception:
            if connection is None:
                conexao.rollback()
            raise
        finally:
            cursor.close()
            if connection is None:
                conexao.close()

    @classmethod
    def has_related_records(cls, id): # USA, DEIXR ESTA FUNÇÃO CORRETA
        conexao = Database.connect()
        cursor = conexao.cursor()
        try:
            queries = [
                "SELECT COUNT(*) FROM movimentacao WHERE produto_id = %s",
                "SELECT COUNT(*) FROM pedido_movimentacao WHERE produto_id = %s"
            ]
            total = 0
            for sql in queries:
                cursor.execute(sql, (id,))
                total += cursor.fetchone()[0]
            return total > 0
        finally:
            cursor.close()
            conexao.close()

    @classmethod
    def safe_delete(cls, id):
        produto = cls.find_by_id(id)
        if not produto:
            raise ValueError("Cãmara fria não encontrada.")
        if cls.has_related_records(id):
            raise ValueError("Não é possível excluir a câmara fria porque ele possui produtos ou está em uso.")
        cls.delete(id)
